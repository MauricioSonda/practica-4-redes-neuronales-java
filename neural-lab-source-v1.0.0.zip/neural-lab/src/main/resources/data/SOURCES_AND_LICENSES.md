# Fuentes y licencias de los datos

## Wine Quality

- Fuente: UCI Machine Learning Repository, DOI `10.24432/C56S3T`.
- Descarga directa: https://archive.ics.uci.edu/static/public/186/wine+quality.zip
- Archivo incluido: `winequality-white.csv`.
- SHA-256: `76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836`.
- Licencia indicada por UCI: Creative Commons Attribution 4.0 (CC BY 4.0).
- Autores: P. Cortez, A. Cerdeira, F. Almeida, T. Matos y J. Reis.

## Airfoil Self-Noise

- Fuente: UCI Machine Learning Repository, DOI `10.24432/C5VW2C`.
- Descarga directa: https://archive.ics.uci.edu/static/public/291/airfoil+self+noise.zip
- Archivo incluido: `airfoil_self_noise.dat`.
- SHA-256: `74c75fd71783f1e6b71f8a622b993dc592897a97cd689c5090a07147a1b097b3`.
- Licencia indicada por UCI: Creative Commons Attribution 4.0 (CC BY 4.0).
- Autores: T. Brooks, D. Pope y M. Marcolini; datos obtenidos en pruebas de NASA.

## ItalyPowerDemand

- Fuente: UCR/UEA Time Series Classification Archive.
- Descarga directa: https://www.timeseriesclassification.com/aeon-toolkit/ItalyPowerDemand.zip
- Archivos incluidos: `ItalyPowerDemand_TRAIN.txt` y `ItalyPowerDemand_TEST.txt`.
- SHA-256 TRAIN: `63bf02d6a32e78729dd2e65e80f7f64bec7a20f9a78e0e2e05f0c8805596bccb`.
- SHA-256 TEST: `ccc6c47d996069ff8c4144d91456abfcee21aadd15f59e7088849e4faa0dbb46`.
- Se redistribuyen sin modificaciones como copia de respaldo académico, conservando la atribución al archivo UCR/UEA.
- Referencia: Dau et al. (2019), *The UCR Time Series Archive*, DOI `10.1109/TKDE.2018.2878259`.
