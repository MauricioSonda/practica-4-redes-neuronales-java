package com.example.neurallab.tasks;

import com.example.neurallab.core.Metrics;
import com.example.neurallab.core.MlpNetwork;
import com.example.neurallab.core.Trainer;
import com.example.neurallab.data.DataUtils;
import com.example.neurallab.data.DatasetLoader;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Regresión del nivel sonoro de perfiles aerodinámicos de NASA. */
@Component
public class RegressionExperiment {
    private static final long SEED = 20261013L;
    private final DatasetLoader loader;

    public RegressionExperiment(DatasetLoader loader) {
        this.loader = loader;
    }

    public Map<String, Object> run(TrainingRequest request) {
        DatasetLoader.RegressionData data = loader.airfoil();
        int[][] split = DataUtils.randomSplit(data.y().length, 0.70, 0.15, SEED);
        double[][] rawTrainX = DataUtils.rows(data.x(), split[0]);
        double[][] rawValidationX = DataUtils.rows(data.x(), split[1]);
        double[][] rawTestX = DataUtils.rows(data.x(), split[2]);
        double[] rawTrainY = DataUtils.values(data.y(), split[0]);
        double[] rawValidationY = DataUtils.values(data.y(), split[1]);
        double[] rawTestY = DataUtils.values(data.y(), split[2]);

        DataUtils.Standardizer xScaler = DataUtils.Standardizer.fit(rawTrainX);
        DataUtils.Standardizer yScaler = DataUtils.Standardizer.fit(DataUtils.column(rawTrainY));
        double[][] trainX = xScaler.transform(rawTrainX);
        double[][] validationX = xScaler.transform(rawValidationX);
        double[][] testX = xScaler.transform(rawTestX);
        double[][] trainY = yScaler.transform(DataUtils.column(rawTrainY));
        double[][] validationY = yScaler.transform(DataUtils.column(rawValidationY));

        int custom = request.neuronsOr(64);
        int[][] architectures = custom == 64
                ? new int[][]{{5, 32, 1}, {5, 64, 32, 1}, {5, 128, 64, 1}}
                : new int[][]{{5, Math.max(8, custom / 2), 1}, {5, custom, Math.max(8, custom / 2), 1},
                {5, Math.min(256, custom * 2), custom, 1}};
        List<Map<String, Object>> comparison = new ArrayList<>();
        MlpNetwork winner = null;
        Trainer.TrainingHistory winnerHistory = null;
        double bestRmse = Double.POSITIVE_INFINITY;
        int[] bestArchitecture = null;

        for (int[] architecture : architectures) {
            MlpNetwork network = new MlpNetwork(architecture, false, SEED);
            Trainer.TrainingHistory history = Trainer.fit(network, trainX, trainY, validationX, validationY,
                    request.epochsOr(500), 32, request.learningRateOr(0.001), 1e-4, 45, SEED, null);
            double[] prediction = predictOriginal(network, validationX, yScaler);
            Map<String, Object> validationMetrics = Metrics.regression(rawValidationY, prediction);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("architecture", Arrays.toString(architecture));
            row.put("bestEpoch", history.bestEpoch());
            row.putAll(validationMetrics);
            comparison.add(row);
            double rmse = ((Number) validationMetrics.get("rmse")).doubleValue();
            if (rmse < bestRmse) {
                bestRmse = rmse;
                winner = network;
                winnerHistory = history;
                bestArchitecture = architecture;
            }
        }

        double[] testPrediction = predictOriginal(winner, testX, yScaler);
        List<Map<String, Double>> points = new ArrayList<>();
        for (int i = 0; i < rawTestY.length; i++) points.add(Map.of("actual", rawTestY[i], "predicted", testPrediction[i]));
        Map<String, Object> result = ClassificationExperiment.base("regression",
                "UCI Airfoil Self-Noise (NASA)", DatasetLoader.AIRFOIL_URL);
        result.put("description", "Predicción del nivel de presión sonora escalado en dB.");
        result.put("splitSizes", Map.of("train", trainX.length, "validation", validationX.length, "test", testX.length));
        result.put("architectureComparisonValidation", comparison);
        result.put("winningArchitecture", Arrays.toString(bestArchitecture));
        result.put("selectionCriterion", "Menor RMSE de validación con idéntico split y semilla.");
        result.put("hyperparameters", Map.of(
                "epochsRequested", request.epochsOr(500), "bestEpoch", winnerHistory.bestEpoch(),
                "learningRate", request.learningRateOr(0.001), "batchSize", 32,
                "optimizer", "Adam", "activation", "ReLU + lineal", "l2", 1e-4,
                "earlyStoppingPatience", 45, "seed", SEED));
        result.put("regularizationRationale", "L2=1e-4 limita pesos sin dominar el error; paciencia=45 tolera mesetas de Adam y restaura la mejor época.");
        result.put("metrics", Metrics.regression(rawTestY, testPrediction));
        result.put("actualVsPredicted", points);
        result.put("lossCurve", ClassificationExperiment.curve(winnerHistory));
        return result;
    }

    private static double[] predictOriginal(MlpNetwork network, double[][] x, DataUtils.Standardizer yScaler) {
        double[] result = new double[x.length];
        for (int i = 0; i < x.length; i++) result[i] = yScaler.inverse(network.predict(x[i]))[0];
        return result;
    }
}
