package com.example.neurallab.tasks;

/** Hiperparámetros que la web permite modificar de forma segura. */
public record TrainingRequest(Integer epochs, Double learningRate, Integer neurons) {
    public static TrainingRequest defaults() {
        return new TrainingRequest(null, null, null);
    }

    public int epochsOr(int value) {
        return epochs == null ? value : Math.max(10, Math.min(epochs, 1000));
    }

    public double learningRateOr(double value) {
        return learningRate == null ? value : Math.max(0.00001, Math.min(learningRate, 0.1));
    }

    public int neuronsOr(int value) {
        return neurons == null ? value : Math.max(4, Math.min(neurons, 256));
    }
}
