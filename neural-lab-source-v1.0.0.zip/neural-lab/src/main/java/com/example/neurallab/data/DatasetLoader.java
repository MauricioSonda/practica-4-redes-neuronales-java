package com.example.neurallab.data;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Descarga los ZIP oficiales; ante cualquier fallo usa la copia incluida en resources/data. */
@Component
public class DatasetLoader {
    public static final String WINE_URL = "https://archive.ics.uci.edu/static/public/186/wine+quality.zip";
    public static final String AIRFOIL_URL = "https://archive.ics.uci.edu/static/public/291/airfoil+self+noise.zip";
    public static final String ITALY_URL = "https://www.timeseriesclassification.com/aeon-toolkit/ItalyPowerDemand.zip";
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
    private final Path cache = Path.of("data-cache");

    public ClassificationData wineQuality() {
        String text = textFromZip(WINE_URL, "wine-quality-white.csv", "data/winequality-white.csv",
                name -> name.endsWith("winequality-white.csv"));
        List<double[]> x = new ArrayList<>();
        List<Integer> y = new ArrayList<>();
        String[] lines = text.split("\\R");
        for (int row = 1; row < lines.length; row++) {
            if (lines[row].isBlank()) continue;
            String[] fields = lines[row].replace("\"", "").split(";");
            double[] features = new double[11];
            for (int i = 0; i < features.length; i++) features[i] = Double.parseDouble(fields[i]);
            int quality = Integer.parseInt(fields[11]);
            // Baja: 3-5; media: 6; alta: 7-9.
            int label = quality <= 5 ? 0 : quality == 6 ? 1 : 2;
            x.add(features);
            y.add(label);
        }
        return new ClassificationData(x.toArray(double[][]::new), y.stream().mapToInt(Integer::intValue).toArray());
    }

    public RegressionData airfoil() {
        String text = textFromZip(AIRFOIL_URL, "airfoil-self-noise.dat", "data/airfoil_self_noise.dat",
                name -> name.endsWith("airfoil_self_noise.dat"));
        List<double[]> x = new ArrayList<>();
        List<Double> y = new ArrayList<>();
        for (String line : text.split("\\R")) {
            if (line.isBlank()) continue;
            String[] fields = line.trim().split("\\s+");
            double[] features = new double[5];
            for (int i = 0; i < features.length; i++) features[i] = Double.parseDouble(fields[i]);
            x.add(features);
            y.add(Double.parseDouble(fields[5]));
        }
        return new RegressionData(x.toArray(double[][]::new), y.stream().mapToDouble(Double::doubleValue).toArray());
    }

    public TimeSeriesData italyPowerDemand() {
        String train = textFromZip(ITALY_URL, "italy-train.txt", "data/ItalyPowerDemand_TRAIN.txt",
                name -> name.endsWith("ItalyPowerDemand_TRAIN.txt"));
        String test = textFromZip(ITALY_URL, "italy-test.txt", "data/ItalyPowerDemand_TEST.txt",
                name -> name.endsWith("ItalyPowerDemand_TEST.txt"));
        ClassificationData trainData = parseUcr(train);
        ClassificationData testData = parseUcr(test);
        return new TimeSeriesData(trainData, testData);
    }

    private ClassificationData parseUcr(String text) {
        List<double[]> x = new ArrayList<>();
        List<Integer> y = new ArrayList<>();
        for (String line : text.split("\\R")) {
            if (line.isBlank()) continue;
            String[] fields = line.trim().split("\\s+");
            // UCR codifica la etiqueta como 1.0000000e+00 / 2.0000000e+00.
            y.add((int) Math.round(Double.parseDouble(fields[0])) - 1);
            double[] values = new double[fields.length - 1];
            for (int i = 1; i < fields.length; i++) values[i - 1] = Double.parseDouble(fields[i]);
            x.add(values);
        }
        return new ClassificationData(x.toArray(double[][]::new), y.stream().mapToInt(Integer::intValue).toArray());
    }

    private String textFromZip(String url, String cacheName, String fallback, Predicate<String> entrySelector) {
        try {
            Files.createDirectories(cache);
            Path cached = cache.resolve(cacheName);
            if (Files.exists(cached)) return Files.readString(cached);
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20)).GET().build();
            HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
            if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode());
            try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(response.body()))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    if (entrySelector.test(entry.getName())) {
                        String text = new String(zip.readAllBytes(), StandardCharsets.UTF_8);
                        Files.writeString(cached, text);
                        return text;
                    }
                }
            }
            throw new IOException("No se encontró el archivo esperado en el ZIP");
        } catch (Exception downloadFailure) {
            try (InputStream in = new ClassPathResource(fallback).getInputStream()) {
                System.out.printf(Locale.ROOT, "Aviso: se usa respaldo local %s (%s)%n", fallback,
                        downloadFailure.getMessage());
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException fallbackFailure) {
                throw new IllegalStateException("Fallaron descarga y respaldo para " + fallback, fallbackFailure);
            }
        }
    }

    public record ClassificationData(double[][] x, int[] y) {}
    public record RegressionData(double[][] x, double[] y) {}
    public record TimeSeriesData(ClassificationData train, ClassificationData test) {}
}
