package com.example.neurallab.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Operaciones de partición y normalización sin fuga de información. */
public final class DataUtils {
    private DataUtils() {}

    public static int[][] stratifiedSplit(int[] labels, double trainRatio, double validationRatio, long seed) {
        int classes = 1;
        for (int label : labels) classes = Math.max(classes, label + 1);
        List<Integer> train = new ArrayList<>();
        List<Integer> validation = new ArrayList<>();
        List<Integer> test = new ArrayList<>();
        for (int c = 0; c < classes; c++) {
            List<Integer> group = new ArrayList<>();
            for (int i = 0; i < labels.length; i++) if (labels[i] == c) group.add(i);
            Collections.shuffle(group, new Random(seed + c));
            int trainEnd = (int) Math.round(group.size() * trainRatio);
            int validationEnd = trainEnd + (int) Math.round(group.size() * validationRatio);
            validationEnd = Math.min(validationEnd, group.size());
            train.addAll(group.subList(0, trainEnd));
            validation.addAll(group.subList(trainEnd, validationEnd));
            test.addAll(group.subList(validationEnd, group.size()));
        }
        Collections.shuffle(train, new Random(seed));
        Collections.shuffle(validation, new Random(seed + 1));
        Collections.shuffle(test, new Random(seed + 2));
        return new int[][]{toArray(train), toArray(validation), toArray(test)};
    }

    public static int[][] randomSplit(int size, double trainRatio, double validationRatio, long seed) {
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < size; i++) order.add(i);
        Collections.shuffle(order, new Random(seed));
        int trainEnd = (int) Math.round(size * trainRatio);
        int validationEnd = trainEnd + (int) Math.round(size * validationRatio);
        return new int[][]{
                toArray(order.subList(0, trainEnd)),
                toArray(order.subList(trainEnd, validationEnd)),
                toArray(order.subList(validationEnd, size))
        };
    }

    public static List<Fold> stratifiedFolds(int[] labels, int k, long seed) {
        List<List<Integer>> bins = new ArrayList<>();
        for (int i = 0; i < k; i++) bins.add(new ArrayList<>());
        int classes = 1;
        for (int label : labels) classes = Math.max(classes, label + 1);
        for (int c = 0; c < classes; c++) {
            List<Integer> group = new ArrayList<>();
            for (int i = 0; i < labels.length; i++) if (labels[i] == c) group.add(i);
            Collections.shuffle(group, new Random(seed + c));
            for (int i = 0; i < group.size(); i++) bins.get(i % k).add(group.get(i));
        }
        List<Fold> folds = new ArrayList<>();
        for (int f = 0; f < k; f++) {
            List<Integer> validation = bins.get(f);
            List<Integer> train = new ArrayList<>();
            for (int j = 0; j < k; j++) if (j != f) train.addAll(bins.get(j));
            folds.add(new Fold(toArray(train), toArray(validation)));
        }
        return folds;
    }

    public static double[][] rows(double[][] source, int[] indices) {
        double[][] result = new double[indices.length][];
        for (int i = 0; i < indices.length; i++) result[i] = source[indices[i]].clone();
        return result;
    }

    public static int[] values(int[] source, int[] indices) {
        int[] result = new int[indices.length];
        for (int i = 0; i < indices.length; i++) result[i] = source[indices[i]];
        return result;
    }

    public static double[] values(double[] source, int[] indices) {
        double[] result = new double[indices.length];
        for (int i = 0; i < indices.length; i++) result[i] = source[indices[i]];
        return result;
    }

    public static double[][] oneHot(int[] labels, int classes) {
        double[][] result = new double[labels.length][classes];
        for (int i = 0; i < labels.length; i++) result[i][labels[i]] = 1.0;
        return result;
    }

    public static double[][] column(double[] values) {
        double[][] result = new double[values.length][1];
        for (int i = 0; i < values.length; i++) result[i][0] = values[i];
        return result;
    }

    public static int[] concat(int[] a, int[] b) {
        int[] result = new int[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }

    private static int[] toArray(List<Integer> values) {
        return values.stream().mapToInt(Integer::intValue).toArray();
    }

    public record Fold(int[] train, int[] validation) {}

    public static final class Standardizer {
        private final double[] mean;
        private final double[] std;

        private Standardizer(double[] mean, double[] std) {
            this.mean = mean;
            this.std = std;
        }

        public static Standardizer fit(double[][] data) {
            int columns = data[0].length;
            double[] mean = new double[columns];
            double[] std = new double[columns];
            for (double[] row : data) for (int j = 0; j < columns; j++) mean[j] += row[j];
            for (int j = 0; j < columns; j++) mean[j] /= data.length;
            for (double[] row : data) for (int j = 0; j < columns; j++) {
                double d = row[j] - mean[j];
                std[j] += d * d;
            }
            for (int j = 0; j < columns; j++) std[j] = Math.max(1e-12, Math.sqrt(std[j] / data.length));
            return new Standardizer(mean, std);
        }

        public double[][] transform(double[][] data) {
            double[][] result = new double[data.length][mean.length];
            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < mean.length; j++) result[i][j] = (data[i][j] - mean[j]) / std[j];
            }
            return result;
        }

        public double[] transform(double[] data) {
            double[] result = new double[data.length];
            for (int j = 0; j < mean.length; j++) result[j] = (data[j] - mean[j]) / std[j];
            return result;
        }

        public double[] inverse(double[] data) {
            double[] result = new double[data.length];
            for (int j = 0; j < mean.length; j++) result[j] = data[j] * std[j] + mean[j];
            return result;
        }
    }
}
