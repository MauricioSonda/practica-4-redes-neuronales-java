package com.example.neurallab.core;

import java.util.Arrays;
import java.util.Random;

/**
 * Perceptrón multicapa denso implementado sin librerías numéricas externas.
 * Usa ReLU en capas ocultas, softmax para clasificación y salida lineal para regresión.
 */
public final class MlpNetwork {
    private final int[] layers;
    private final boolean classification;
    private final double[][][] weights;
    private final double[][] biases;
    private final double[][][] mw;
    private final double[][][] vw;
    private final double[][] mb;
    private final double[][] vb;
    private long adamStep = 0;

    public MlpNetwork(int[] layers, boolean classification, long seed) {
        if (layers.length < 2) throw new IllegalArgumentException("Se requieren entrada y salida");
        this.layers = layers.clone();
        this.classification = classification;
        this.weights = new double[layers.length - 1][][];
        this.biases = new double[layers.length - 1][];
        this.mw = new double[layers.length - 1][][];
        this.vw = new double[layers.length - 1][][];
        this.mb = new double[layers.length - 1][];
        this.vb = new double[layers.length - 1][];
        Random random = new Random(seed);
        for (int l = 0; l < weights.length; l++) {
            int in = layers[l];
            int out = layers[l + 1];
            weights[l] = new double[out][in];
            mw[l] = new double[out][in];
            vw[l] = new double[out][in];
            biases[l] = new double[out];
            mb[l] = new double[out];
            vb[l] = new double[out];
            double scale = Math.sqrt(2.0 / in);
            for (int j = 0; j < out; j++) {
                for (int i = 0; i < in; i++) weights[l][j][i] = random.nextGaussian() * scale;
            }
        }
    }

    public int[] shape() {
        return layers.clone();
    }

    public double[] predict(double[] input) {
        return forward(input).activations[layers.length - 1].clone();
    }

    public int predictClass(double[] input) {
        double[] output = predict(input);
        int best = 0;
        for (int i = 1; i < output.length; i++) if (output[i] > output[best]) best = i;
        return best;
    }

    /** Aplica un paso Adam con el gradiente medio de un mini-batch. */
    public double trainBatch(double[][] x, double[][] y, int[] indices, int from, int to,
                             double learningRate, double l2, double[] classWeights) {
        Gradients sum = new Gradients(layers);
        double loss = 0.0;
        for (int p = from; p < to; p++) {
            int index = indices[p];
            double sampleWeight = 1.0;
            if (classification && classWeights != null) sampleWeight = classWeights[argmax(y[index])];
            Gradients gradient = gradient(x[index], y[index], sampleWeight);
            sum.add(gradient);
            loss += sampleLoss(x[index], y[index], classWeights);
        }
        int count = to - from;
        adamStep++;
        double beta1 = 0.9;
        double beta2 = 0.999;
        double eps = 1e-8;
        double correction1 = 1.0 - Math.pow(beta1, adamStep);
        double correction2 = 1.0 - Math.pow(beta2, adamStep);
        for (int l = 0; l < weights.length; l++) {
            for (int j = 0; j < weights[l].length; j++) {
                for (int i = 0; i < weights[l][j].length; i++) {
                    double g = sum.dw[l][j][i] / count + l2 * weights[l][j][i];
                    mw[l][j][i] = beta1 * mw[l][j][i] + (1 - beta1) * g;
                    vw[l][j][i] = beta2 * vw[l][j][i] + (1 - beta2) * g * g;
                    double mHat = mw[l][j][i] / correction1;
                    double vHat = vw[l][j][i] / correction2;
                    weights[l][j][i] -= learningRate * mHat / (Math.sqrt(vHat) + eps);
                }
                double g = sum.db[l][j] / count;
                mb[l][j] = beta1 * mb[l][j] + (1 - beta1) * g;
                vb[l][j] = beta2 * vb[l][j] + (1 - beta2) * g * g;
                biases[l][j] -= learningRate * (mb[l][j] / correction1) /
                        (Math.sqrt(vb[l][j] / correction2) + eps);
            }
        }
        return loss / count;
    }

    public double meanLoss(double[][] x, double[][] y, double[] classWeights) {
        double total = 0;
        for (int i = 0; i < x.length; i++) total += sampleLoss(x[i], y[i], classWeights);
        return total / x.length;
    }

    public double sampleLoss(double[] x, double[] y, double[] classWeights) {
        double[] output = predict(x);
        if (classification) {
            int label = argmax(y);
            double weight = classWeights == null ? 1.0 : classWeights[label];
            return -weight * Math.log(Math.max(1e-12, output[label]));
        }
        double sum = 0;
        for (int i = 0; i < output.length; i++) {
            double d = output[i] - y[i];
            sum += 0.5 * d * d;
        }
        return sum;
    }

    /** Error relativo máximo entre backpropagation y diferencias finitas. */
    public double gradientCheck(double[] x, double[] y, double epsilon) {
        Gradients analytic = gradient(x, y, 1.0);
        double maxRelativeError = 0.0;
        for (int l = 0; l < weights.length; l++) {
            for (int j = 0; j < weights[l].length; j++) {
                for (int i = 0; i < weights[l][j].length; i++) {
                    double original = weights[l][j][i];
                    weights[l][j][i] = original + epsilon;
                    double plus = sampleLoss(x, y, null);
                    weights[l][j][i] = original - epsilon;
                    double minus = sampleLoss(x, y, null);
                    weights[l][j][i] = original;
                    double numerical = (plus - minus) / (2 * epsilon);
                    double expected = analytic.dw[l][j][i];
                    double denominator = Math.max(1e-9, Math.abs(numerical) + Math.abs(expected));
                    maxRelativeError = Math.max(maxRelativeError, Math.abs(numerical - expected) / denominator);
                }
            }
        }
        return maxRelativeError;
    }

    public Snapshot snapshot() {
        return new Snapshot(copy3(weights), copy2(biases));
    }

    public void restore(Snapshot snapshot) {
        for (int l = 0; l < weights.length; l++) {
            for (int j = 0; j < weights[l].length; j++) {
                System.arraycopy(snapshot.weights[l][j], 0, weights[l][j], 0, weights[l][j].length);
            }
            for (int j = 0; j < biases[l].length; j++) biases[l][j] = snapshot.biases[l][j];
        }
    }

    private Gradients gradient(double[] input, double[] target, double sampleWeight) {
        ForwardPass pass = forward(input);
        Gradients result = new Gradients(layers);
        int last = layers.length - 1;
        double[] delta = new double[layers[last]];
        for (int j = 0; j < delta.length; j++) {
            // Softmax + entropía cruzada y salida lineal + 1/2 MSE comparten (predicción - objetivo).
            delta[j] = (pass.activations[last][j] - target[j]) * sampleWeight;
        }
        for (int l = weights.length - 1; l >= 0; l--) {
            for (int j = 0; j < weights[l].length; j++) {
                result.db[l][j] = delta[j];
                for (int i = 0; i < weights[l][j].length; i++) {
                    result.dw[l][j][i] = delta[j] * pass.activations[l][i];
                }
            }
            if (l > 0) {
                double[] previous = new double[layers[l]];
                for (int i = 0; i < previous.length; i++) {
                    double sum = 0;
                    for (int j = 0; j < delta.length; j++) sum += weights[l][j][i] * delta[j];
                    previous[i] = pass.preActivations[l - 1][i] > 0 ? sum : 0.0;
                }
                delta = previous;
            }
        }
        return result;
    }

    private ForwardPass forward(double[] input) {
        if (input.length != layers[0]) throw new IllegalArgumentException("Entrada de tamaño incorrecto");
        double[][] activations = new double[layers.length][];
        double[][] zs = new double[layers.length - 1][];
        activations[0] = input.clone();
        for (int l = 0; l < weights.length; l++) {
            zs[l] = new double[layers[l + 1]];
            for (int j = 0; j < zs[l].length; j++) {
                double sum = biases[l][j];
                for (int i = 0; i < weights[l][j].length; i++) sum += weights[l][j][i] * activations[l][i];
                zs[l][j] = sum;
            }
            boolean outputLayer = l == weights.length - 1;
            if (outputLayer && classification) activations[l + 1] = softmax(zs[l]);
            else if (outputLayer) activations[l + 1] = zs[l].clone();
            else {
                activations[l + 1] = new double[zs[l].length];
                for (int j = 0; j < zs[l].length; j++) activations[l + 1][j] = Math.max(0, zs[l][j]);
            }
        }
        return new ForwardPass(activations, zs);
    }

    private static double[] softmax(double[] values) {
        double max = Arrays.stream(values).max().orElse(0);
        double sum = 0;
        double[] result = new double[values.length];
        for (int i = 0; i < values.length; i++) {
            result[i] = Math.exp(values[i] - max);
            sum += result[i];
        }
        for (int i = 0; i < result.length; i++) result[i] /= sum;
        return result;
    }

    private static int argmax(double[] values) {
        int best = 0;
        for (int i = 1; i < values.length; i++) if (values[i] > values[best]) best = i;
        return best;
    }

    private static double[][][] copy3(double[][][] source) {
        double[][][] copy = new double[source.length][][];
        for (int i = 0; i < source.length; i++) copy[i] = copy2(source[i]);
        return copy;
    }

    private static double[][] copy2(double[][] source) {
        double[][] copy = new double[source.length][];
        for (int i = 0; i < source.length; i++) copy[i] = source[i].clone();
        return copy;
    }

    public record Snapshot(double[][][] weights, double[][] biases) {}
    private record ForwardPass(double[][] activations, double[][] preActivations) {}

    private static final class Gradients {
        private final double[][][] dw;
        private final double[][] db;

        private Gradients(int[] layers) {
            dw = new double[layers.length - 1][][];
            db = new double[layers.length - 1][];
            for (int l = 0; l < layers.length - 1; l++) {
                dw[l] = new double[layers[l + 1]][layers[l]];
                db[l] = new double[layers[l + 1]];
            }
        }

        private void add(Gradients other) {
            for (int l = 0; l < dw.length; l++) {
                for (int j = 0; j < dw[l].length; j++) {
                    db[l][j] += other.db[l][j];
                    for (int i = 0; i < dw[l][j].length; i++) dw[l][j][i] += other.dw[l][j][i];
                }
            }
        }
    }
}
