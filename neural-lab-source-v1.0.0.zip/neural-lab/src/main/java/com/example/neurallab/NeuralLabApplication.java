package com.example.neurallab;

import com.example.neurallab.tasks.ExperimentService;
import com.example.neurallab.tasks.TrainingRequest;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Arrays;

/** Punto de entrada web y CLI del laboratorio. */
@SpringBootApplication
public class NeuralLabApplication {

    public static void main(String[] args) {
        String mode = args.length == 0 ? "web" : args[0].toLowerCase();
        if (mode.equals("web")) {
            new SpringApplicationBuilder(NeuralLabApplication.class).run(args);
            return;
        }

        if (!Arrays.asList("classification", "regression", "timeseries", "all").contains(mode)) {
            System.err.println("Uso: java -jar app.jar [classification|regression|timeseries|all|web]");
            System.exit(2);
        }

        try (ConfigurableApplicationContext context = new SpringApplicationBuilder(NeuralLabApplication.class)
                .web(WebApplicationType.NONE)
                .run(args)) {
            ExperimentService service = context.getBean(ExperimentService.class);
            TrainingRequest request = TrainingRequest.defaults();
            if (mode.equals("all")) {
                service.runAndSave("classification", request);
                service.runAndSave("regression", request);
                service.runAndSave("timeseries", request);
            } else {
                service.runAndSave(mode, request);
            }
        }
    }
}
