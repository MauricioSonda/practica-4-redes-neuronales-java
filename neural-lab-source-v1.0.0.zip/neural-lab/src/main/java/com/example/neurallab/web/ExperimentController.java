package com.example.neurallab.web;

import com.example.neurallab.tasks.ExperimentService;
import com.example.neurallab.tasks.TrainingRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class ExperimentController {
    private final ExperimentService service;

    public ExperimentController(ExperimentService service) {
        this.service = service;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "java", System.getProperty("java.version"));
    }

    @GetMapping("/results/{type}")
    public Map<String, Object> result(@PathVariable String type) {
        return service.precomputed(type);
    }

    @PostMapping("/train/{type}")
    public Map<String, Object> train(@PathVariable String type,
                                     @RequestBody(required = false) TrainingRequest request) {
        return service.runAndSave(type, request == null ? TrainingRequest.defaults() : request);
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class})
    public ResponseEntity<Map<String, String>> error(RuntimeException exception) {
        return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage()));
    }
}
