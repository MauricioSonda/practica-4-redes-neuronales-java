package com.example.neurallab.tasks;

import com.example.neurallab.core.Metrics;
import com.example.neurallab.core.MlpNetwork;
import com.example.neurallab.core.Trainer;
import com.example.neurallab.data.DataUtils;
import com.example.neurallab.data.DatasetLoader;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Clasificación binaria de curvas diarias de demanda eléctrica. */
@Component
public class TimeSeriesExperiment {
    private static final long SEED = 20261013L;
    private final DatasetLoader loader;

    public TimeSeriesExperiment(DatasetLoader loader) {
        this.loader = loader;
    }

    public Map<String, Object> run(TrainingRequest request) {
        DatasetLoader.TimeSeriesData dataset = loader.italyPowerDemand();
        double[][] rawX = dataset.train().x();
        int[] labels = dataset.train().y();
        int custom = request.neuronsOr(32);
        int[][] candidates = custom == 32
                ? new int[][]{{24, 16, 2}, {24, 32, 16, 2}, {24, 64, 32, 2}}
                : new int[][]{{24, Math.max(8, custom / 2), 2}, {24, custom, Math.max(8, custom / 2), 2},
                {24, Math.min(128, custom * 2), custom, 2}};
        List<DataUtils.Fold> folds = DataUtils.stratifiedFolds(labels, 5, SEED);
        List<Map<String, Object>> comparison = new ArrayList<>();
        int[] winnerArchitecture = null;
        double bestCvF1 = -1;
        int winnerEpochs = 1;

        for (int candidateIndex = 0; candidateIndex < candidates.length; candidateIndex++) {
            int[] architecture = candidates[candidateIndex];
            double accuracySum = 0;
            double f1Sum = 0;
            int epochSum = 0;
            List<Map<String, Object>> foldResults = new ArrayList<>();
            for (int f = 0; f < folds.size(); f++) {
                DataUtils.Fold fold = folds.get(f);
                double[][] foldTrainRaw = DataUtils.rows(rawX, fold.train());
                double[][] foldValidationRaw = DataUtils.rows(rawX, fold.validation());
                DataUtils.Standardizer scaler = DataUtils.Standardizer.fit(foldTrainRaw);
                double[][] foldTrainX = scaler.transform(foldTrainRaw);
                double[][] foldValidationX = scaler.transform(foldValidationRaw);
                int[] foldTrainLabels = DataUtils.values(labels, fold.train());
                int[] foldValidationLabels = DataUtils.values(labels, fold.validation());
                MlpNetwork network = new MlpNetwork(architecture, true, SEED + f);
                Trainer.TrainingHistory history = Trainer.fit(network, foldTrainX, DataUtils.oneHot(foldTrainLabels, 2),
                        foldValidationX, DataUtils.oneHot(foldValidationLabels, 2), request.epochsOr(400), 8,
                        request.learningRateOr(0.001), 1e-4, 40, SEED + f, null);
                Map<String, Object> metrics = Metrics.classification(foldValidationLabels,
                        ClassificationExperiment.predict(network, foldValidationX), new String[]{"Clase 1", "Clase 2"});
                double accuracy = ((Number) metrics.get("accuracy")).doubleValue();
                double f1 = ((Number) metrics.get("macroF1")).doubleValue();
                accuracySum += accuracy;
                f1Sum += f1;
                epochSum += history.bestEpoch();
                foldResults.add(Map.of("fold", f + 1, "accuracy", accuracy, "macroF1", f1,
                        "bestEpoch", history.bestEpoch()));
            }
            double meanAccuracy = accuracySum / folds.size();
            double meanF1 = f1Sum / folds.size();
            int meanEpoch = Math.max(1, (int) Math.round((double) epochSum / folds.size()));
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("architecture", Arrays.toString(architecture));
            row.put("meanAccuracy", meanAccuracy);
            row.put("meanMacroF1", meanF1);
            row.put("meanBestEpoch", meanEpoch);
            row.put("folds", foldResults);
            comparison.add(row);
            if (meanF1 > bestCvF1) {
                bestCvF1 = meanF1;
                winnerArchitecture = architecture;
                winnerEpochs = meanEpoch;
            }
        }

        // La selección terminó: se ajusta una vez con las 67 muestras y se abre el test oficial una sola vez.
        DataUtils.Standardizer finalScaler = DataUtils.Standardizer.fit(rawX);
        double[][] trainX = finalScaler.transform(rawX);
        MlpNetwork finalNetwork = new MlpNetwork(winnerArchitecture, true, SEED);
        Trainer.TrainingHistory history = Trainer.fitFixed(finalNetwork, trainX, DataUtils.oneHot(labels, 2),
                winnerEpochs, 8, request.learningRateOr(0.001), 1e-4, SEED, null);
        double[][] testX = finalScaler.transform(dataset.test().x());
        int[] predicted = ClassificationExperiment.predict(finalNetwork, testX);
        Map<String, Object> metrics = Metrics.classification(dataset.test().y(), predicted,
                new String[]{"Clase 1", "Clase 2"});

        Map<String, Object> result = ClassificationExperiment.base("timeseries",
                "UCR ItalyPowerDemand", DatasetLoader.ITALY_URL);
        result.put("description", "Cada ejemplo contiene 24 mediciones horarias; se conserva el test oficial de 1,029 series.");
        result.put("officialSizes", Map.of("train", rawX.length, "test", testX.length, "seriesLength", 24));
        result.put("crossValidation", Map.of("strategy", "5-fold estratificada solo sobre TRAIN oficial", "candidates", comparison));
        result.put("winningArchitecture", Arrays.toString(winnerArchitecture));
        result.put("finalEpochsFromCv", winnerEpochs);
        result.put("hyperparameters", Map.of("learningRate", request.learningRateOr(0.001), "batchSize", 8,
                "optimizer", "Adam", "activation", "ReLU + softmax", "l2", 1e-4, "seed", SEED));
        result.put("metrics", metrics);
        result.put("f1Definition", "F1 macro de las dos clases");
        result.put("lossCurve", ClassificationExperiment.curve(history));
        result.put("cnnVariant", "No incluida: se priorizó una implementación MLP breve, auditable y reproducible, tal como se solicitó como base.");
        return result;
    }
}
