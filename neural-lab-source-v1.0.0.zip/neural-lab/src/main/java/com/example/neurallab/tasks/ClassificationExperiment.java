package com.example.neurallab.tasks;

import com.example.neurallab.core.Metrics;
import com.example.neurallab.core.MlpNetwork;
import com.example.neurallab.core.Trainer;
import com.example.neurallab.data.DataUtils;
import com.example.neurallab.data.DatasetLoader;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Clasificación de calidad comercial del vino blanco. */
@Component
public class ClassificationExperiment {
    private static final long SEED = 20261013L;
    private final DatasetLoader loader;

    public ClassificationExperiment(DatasetLoader loader) {
        this.loader = loader;
    }

    public Map<String, Object> run(TrainingRequest request) {
        DatasetLoader.ClassificationData data = loader.wineQuality();
        int[] distribution = new int[3];
        for (int label : data.y()) distribution[label]++;
        int[][] split = DataUtils.stratifiedSplit(data.y(), 0.70, 0.15, SEED);
        double[][] rawTrain = DataUtils.rows(data.x(), split[0]);
        DataUtils.Standardizer standardizer = DataUtils.Standardizer.fit(rawTrain);
        double[][] trainX = standardizer.transform(rawTrain);
        double[][] validationX = standardizer.transform(DataUtils.rows(data.x(), split[1]));
        double[][] testX = standardizer.transform(DataUtils.rows(data.x(), split[2]));
        int[] trainLabels = DataUtils.values(data.y(), split[0]);
        int[] validationLabels = DataUtils.values(data.y(), split[1]);
        int[] testLabels = DataUtils.values(data.y(), split[2]);
        double[][] trainY = DataUtils.oneHot(trainLabels, 3);
        double[][] validationY = DataUtils.oneHot(validationLabels, 3);

        double[] classWeights = classWeights(trainLabels, 3);
        int neurons = request.neuronsOr(32);
        int[][] candidates = request.neurons() == null
                ? new int[][]{{11, 16, 8, 3}, {11, 32, 16, 3}, {11, 64, 32, 3}}
                : new int[][]{{11, neurons, Math.max(8, neurons / 2), 3}};
        List<Map<String, Object>> comparison = new java.util.ArrayList<>();
        MlpNetwork network = null;
        Trainer.TrainingHistory history = null;
        int[] architecture = null;
        double bestMacroF1 = -1;
        for (int[] candidate : candidates) {
            MlpNetwork trained = new MlpNetwork(candidate, true, SEED);
            Trainer.TrainingHistory candidateHistory = Trainer.fit(trained, trainX, trainY,
                    validationX, validationY, request.epochsOr(260), 64,
                    request.learningRateOr(0.001), 1e-4, 35, SEED, classWeights);
            Map<String, Object> validationMetrics = Metrics.classification(validationLabels,
                    predict(trained, validationX), new String[]{"Baja", "Media", "Alta"});
            double macroF1 = ((Number) validationMetrics.get("macroF1")).doubleValue();
            comparison.add(Map.of("architecture", Arrays.toString(candidate),
                    "accuracy", validationMetrics.get("accuracy"), "macroF1", macroF1,
                    "bestEpoch", candidateHistory.bestEpoch()));
            if (macroF1 > bestMacroF1) {
                bestMacroF1 = macroF1;
                network = trained;
                history = candidateHistory;
                architecture = candidate;
            }
        }
        int[] predicted = predict(network, testX);

        Map<String, Object> result = base("classification", "UCI Wine Quality (white)", DatasetLoader.WINE_URL);
        result.put("description", "Calidad 3-5=baja, 6=media y 7-9=alta.");
        result.put("originalQualityRange", "3 a 9");
        result.put("classGrouping", Map.of("baja", "3-5", "media", "6", "alta", "7-9"));
        result.put("fullDistribution", Map.of("baja", distribution[0], "media", distribution[1], "alta", distribution[2]));
        result.put("splitSizes", Map.of("train", trainX.length, "validation", validationX.length, "test", testX.length));
        result.put("architecture", Arrays.toString(architecture));
        result.put("architectureComparisonValidation", comparison);
        result.put("selectionCriterion", "Mayor F1 macro de validación; el test se usa una sola vez después de elegir.");
        result.put("hyperparameters", Map.of(
                "epochsRequested", request.epochsOr(260), "bestEpoch", history.bestEpoch(),
                "learningRate", request.learningRateOr(0.001), "batchSize", 64,
                "optimizer", "Adam", "activation", "ReLU + softmax", "l2", 1e-4,
                "earlyStoppingPatience", 35, "seed", SEED));
        result.put("imbalanceTechnique", "Entropía cruzada con pesos sqrt(N/(K*n_clase)); modera el desbalance sin sobrerreaccionar.");
        result.put("classWeights", classWeights);
        result.put("metrics", Metrics.classification(testLabels, predicted, new String[]{"Baja", "Media", "Alta"}));
        result.put("lossCurve", curve(history));
        return result;
    }

    private static double[] classWeights(int[] labels, int classes) {
        int[] counts = new int[classes];
        for (int label : labels) counts[label]++;
        double[] weights = new double[classes];
        for (int c = 0; c < classes; c++) weights[c] = Math.sqrt((double) labels.length / (classes * counts[c]));
        return weights;
    }

    static int[] predict(MlpNetwork network, double[][] x) {
        int[] result = new int[x.length];
        for (int i = 0; i < x.length; i++) result[i] = network.predictClass(x[i]);
        return result;
    }

    static List<Map<String, Object>> curve(Trainer.TrainingHistory history) {
        java.util.ArrayList<Map<String, Object>> curve = new java.util.ArrayList<>();
        for (int i = 0; i < history.trainLoss().size(); i++) {
            curve.add(Map.of("epoch", i + 1, "train", history.trainLoss().get(i),
                    "validation", history.validationLoss().get(i)));
        }
        return curve;
    }

    static Map<String, Object> base(String type, String dataset, String url) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("experiment", type);
        result.put("generatedAt", Instant.now().toString());
        result.put("dataset", dataset);
        result.put("downloadUrl", url);
        result.put("resultType", "real-training-run");
        return result;
    }
}
