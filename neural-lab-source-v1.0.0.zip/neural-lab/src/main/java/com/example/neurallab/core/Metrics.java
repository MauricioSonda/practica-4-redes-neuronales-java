package com.example.neurallab.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Métricas puras usadas por CLI, API y archivos precalculados. */
public final class Metrics {
    private Metrics() {}

    public static Map<String, Object> classification(int[] actual, int[] predicted, String[] names) {
        int[][] matrix = new int[names.length][names.length];
        for (int i = 0; i < actual.length; i++) matrix[actual[i]][predicted[i]]++;
        int correct = 0;
        for (int c = 0; c < names.length; c++) correct += matrix[c][c];
        List<Map<String, Object>> perClass = new ArrayList<>();
        double macroF1 = 0;
        double weightedF1 = 0;
        int totalSupport = 0;
        for (int c = 0; c < names.length; c++) {
            int tp = matrix[c][c];
            int fp = 0;
            int fn = 0;
            int support = 0;
            for (int j = 0; j < names.length; j++) {
                if (j != c) {
                    fp += matrix[j][c];
                    fn += matrix[c][j];
                }
                support += matrix[c][j];
            }
            double precision = safe(tp, tp + fp);
            double recall = safe(tp, tp + fn);
            double f1 = precision + recall == 0 ? 0 : 2 * precision * recall / (precision + recall);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("className", names[c]);
            row.put("precision", precision);
            row.put("recall", recall);
            row.put("f1", f1);
            row.put("support", support);
            perClass.add(row);
            macroF1 += f1;
            weightedF1 += f1 * support;
            totalSupport += support;
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("accuracy", (double) correct / actual.length);
        result.put("macroF1", macroF1 / names.length);
        result.put("weightedF1", weightedF1 / totalSupport);
        result.put("perClass", perClass);
        result.put("confusionMatrix", matrix);
        result.put("classNames", names);
        return result;
    }

    public static Map<String, Object> regression(double[] actual, double[] predicted) {
        double squared = 0;
        double absolute = 0;
        double mean = 0;
        for (double value : actual) mean += value;
        mean /= actual.length;
        double total = 0;
        for (int i = 0; i < actual.length; i++) {
            double error = actual[i] - predicted[i];
            squared += error * error;
            absolute += Math.abs(error);
            double centered = actual[i] - mean;
            total += centered * centered;
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("rmse", Math.sqrt(squared / actual.length));
        result.put("mae", absolute / actual.length);
        result.put("r2", 1.0 - squared / total);
        return result;
    }

    private static double safe(int numerator, int denominator) {
        return denominator == 0 ? 0 : (double) numerator / denominator;
    }
}
