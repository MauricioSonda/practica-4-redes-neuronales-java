package com.example.neurallab.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Entrenamiento reproducible con Adam, mini-batches y parada temprana. */
public final class Trainer {
    private Trainer() {}

    public static TrainingHistory fit(MlpNetwork network, double[][] trainX, double[][] trainY,
                                      double[][] validationX, double[][] validationY,
                                      int epochs, int batchSize, double learningRate, double l2,
                                      int patience, long seed, double[] classWeights) {
        List<Double> trainLoss = new ArrayList<>();
        List<Double> validationLoss = new ArrayList<>();
        MlpNetwork.Snapshot best = network.snapshot();
        double bestValidation = Double.POSITIVE_INFINITY;
        int bestEpoch = 0;
        int stale = 0;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < trainX.length; i++) order.add(i);

        for (int epoch = 0; epoch < epochs; epoch++) {
            Collections.shuffle(order, new Random(seed + epoch));
            int[] indices = order.stream().mapToInt(Integer::intValue).toArray();
            for (int from = 0; from < indices.length; from += batchSize) {
                int to = Math.min(indices.length, from + batchSize);
                network.trainBatch(trainX, trainY, indices, from, to, learningRate, l2, classWeights);
            }
            double training = network.meanLoss(trainX, trainY, classWeights);
            double validation = validationX == null || validationX.length == 0
                    ? training : network.meanLoss(validationX, validationY, classWeights);
            trainLoss.add(training);
            validationLoss.add(validation);
            if (validation < bestValidation - 1e-7) {
                bestValidation = validation;
                bestEpoch = epoch + 1;
                best = network.snapshot();
                stale = 0;
            } else if (++stale >= patience) {
                break;
            }
        }
        network.restore(best);
        return new TrainingHistory(trainLoss, validationLoss, bestEpoch, bestValidation);
    }

    /** Entrena exactamente N épocas; se usa tras CV para aprovechar las 67 series oficiales. */
    public static TrainingHistory fitFixed(MlpNetwork network, double[][] x, double[][] y,
                                           int epochs, int batchSize, double learningRate,
                                           double l2, long seed, double[] classWeights) {
        return fit(network, x, y, null, null, epochs, batchSize, learningRate, l2,
                epochs + 1, seed, classWeights);
    }

    public record TrainingHistory(List<Double> trainLoss, List<Double> validationLoss,
                                  int bestEpoch, double bestValidationLoss) {}
}
