package com.example.neurallab.tasks;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/** Orquesta experimentos y persiste cada ejecución real como JSON reutilizable. */
@Service
public class ExperimentService {
    private final ClassificationExperiment classification;
    private final RegressionExperiment regression;
    private final TimeSeriesExperiment timeSeries;
    private final ObjectMapper mapper;

    public ExperimentService(ClassificationExperiment classification, RegressionExperiment regression,
                             TimeSeriesExperiment timeSeries, ObjectMapper mapper) {
        this.classification = classification;
        this.regression = regression;
        this.timeSeries = timeSeries;
        this.mapper = mapper;
    }

    public Map<String, Object> runAndSave(String type, TrainingRequest request) {
        Map<String, Object> result = switch (type) {
            case "classification" -> classification.run(request);
            case "regression" -> regression.run(request);
            case "timeseries" -> timeSeries.run(request);
            default -> throw new IllegalArgumentException("Experimento desconocido: " + type);
        };
        try {
            Path directory = Path.of("runtime-results");
            Files.createDirectories(directory);
            Path output = directory.resolve(type + ".json");
            mapper.writerWithDefaultPrettyPrinter().writeValue(output.toFile(), result);
            System.out.println("Resultado real guardado en " + output.toAbsolutePath());
            System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(result.get("metrics")));
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo guardar el resultado", e);
        }
        return result;
    }

    public Map<String, Object> precomputed(String type) {
        Path runtime = Path.of("runtime-results", type + ".json");
        try {
            if (Files.exists(runtime)) return mapper.readValue(runtime.toFile(), new TypeReference<>() {});
            ClassPathResource resource = new ClassPathResource("static/results/" + type + ".json");
            try (InputStream input = resource.getInputStream()) {
                return mapper.readValue(input, new TypeReference<>() {});
            }
        } catch (Exception e) {
            throw new IllegalStateException("Aún no existe resultado precalculado para " + type, e);
        }
    }
}
