package com.example.neurallab.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MlpNetworkTest {

    @Test
    void softmaxSumaUnoYTieneFormaCorrecta() {
        MlpNetwork network = new MlpNetwork(new int[]{4, 5, 3}, true, 7L);
        double[] output = network.predict(new double[]{0.2, -0.4, 0.7, 1.1});
        assertEquals(3, output.length);
        assertEquals(1.0, java.util.Arrays.stream(output).sum(), 1e-12);
        assertTrue(java.util.Arrays.stream(output).allMatch(value -> value > 0 && value < 1));
    }

    @Test
    void salidaDeRegresionTieneLaFormaSolicitada() {
        MlpNetwork network = new MlpNetwork(new int[]{5, 8, 1}, false, 11L);
        assertEquals(1, network.predict(new double[]{1, 2, 3, 4, 5}).length);
    }

    @Test
    void gradienteCoincideConDiferenciasFinitas() {
        MlpNetwork network = new MlpNetwork(new int[]{3, 4, 2}, true, 23L);
        double error = network.gradientCheck(new double[]{0.4, -0.3, 0.8}, new double[]{1, 0}, 1e-5);
        assertTrue(error < 1e-5, "Error relativo del gradiente: " + error);
    }
}
