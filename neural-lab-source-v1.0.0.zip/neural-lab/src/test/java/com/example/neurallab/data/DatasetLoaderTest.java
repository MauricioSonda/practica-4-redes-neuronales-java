package com.example.neurallab.data;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DatasetLoaderTest {
    @Test
    void respaldosIncluidosTienenLasDimensionesOficiales() {
        DatasetLoader loader = new DatasetLoader();
        DatasetLoader.ClassificationData wine = loader.wineQuality();
        DatasetLoader.RegressionData airfoil = loader.airfoil();
        DatasetLoader.TimeSeriesData italy = loader.italyPowerDemand();
        assertEquals(4898, wine.x().length);
        assertEquals(11, wine.x()[0].length);
        assertEquals(1503, airfoil.x().length);
        assertEquals(67, italy.train().x().length);
        assertEquals(1029, italy.test().x().length);
        assertEquals(24, italy.test().x()[0].length);
        int[] counts = new int[3];
        for (int label : wine.y()) counts[label]++;
        assertArrayEquals(new int[]{1640, 2198, 1060}, counts);
    }
}
