# Uso de IA generativa

## Herramienta utilizada

- Proveedor y modelo: [escribir el nombre exacto mostrado en la aplicación]
- Fecha de uso: [AAAA-MM-DD]
- Finalidad: apoyo en diseño, implementación, depuración, documentación y análisis de resultados.

## Declaración

Se utilizó una herramienta de IA generativa como asistente durante el desarrollo. Las decisiones técnicas, la ejecución del código, la comprobación de las métricas y la revisión del contenido fueron realizadas y validadas por el autor del trabajo. Los resultados numéricos presentados proceden de ejecuciones reproducibles del programa con semillas fijas y no fueron inventados por la IA.

## Prompts utilizados

### Prompt 1

> [Pegar aquí el prompt completo]

**Uso de la respuesta:** [explicar qué se aceptó, modificó o descartó].

### Prompt 2

> [Pegar aquí el prompt completo]

**Uso de la respuesta:** [explicar qué se aceptó, modificó o descartó].

## Verificación humana

- [ ] Compilé el proyecto y ejecuté las pruebas.
- [ ] Confirmé las fuentes y licencias de los datasets.
- [ ] Repetí los entrenamientos y revisé las métricas.
- [ ] Revisé y comprendí el código entregado.
